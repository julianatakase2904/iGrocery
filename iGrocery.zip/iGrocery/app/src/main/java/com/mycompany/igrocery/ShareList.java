package com.mycompany.igrocery;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ShareList extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_share_list);
    }
}